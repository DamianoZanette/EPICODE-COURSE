<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ritrovati' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pGEQ*4-VEZ(8}]GEx1GJ@f^Rg4,dLD{NJ.#=xAz)5F*%{]dq3VoR|UK4}c<X)KA5' );
define( 'SECURE_AUTH_KEY',  'i4wPuOd~PC%q*#[%b9m[t2L6&pmlnd+gF_8!=:Kk;4@5a*Ni?#y1Mo8_b^)Usl<m' );
define( 'LOGGED_IN_KEY',    'xtpa]d4Y9lkyHIVDZ{#s#Q~CX/qtUVLMFIY.(KT{D):2aY::a8*h4T8:@d5[yed|' );
define( 'NONCE_KEY',        'Szbn@+iG6nsLT/13kiW#*h9#qhZTP{]}gXININ)I?3DSqiLYF`[~>)?J%p0a/S&O' );
define( 'AUTH_SALT',        '3^Br?07Mi9$>,X[5uiBoo[ ~]z~K(L]{: S+Mp#WfB^.o=<7b34ESXB4-@NA/EBi' );
define( 'SECURE_AUTH_SALT', 'yACBr@6>qWHf21i|3sz%:Pf6m|F~xqTb6?sY>eLAOx+fAw~8q{0n8ST<Yf.[+Fy{' );
define( 'LOGGED_IN_SALT',   'BjS8$NLNV=>=S?pS6R^%qVD6d4Qd%0Ga{xQ@]E .&DyD;u$17oN]`?G7SP+0E;AV' );
define( 'NONCE_SALT',       'Z7K$<sJ)9DO+Pxfdpp%#D&ag6PZnO}Dgc8K_s.(wJx^v$ufb<}=e^7*Nz#^HpI)=' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'ri_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
